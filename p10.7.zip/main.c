/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
struct card{
    char*face;
    char*suit;
};
int main(int)
{
    struct card aCard;
    struct card *cardPtr;
    aCard.face ="Ace";
    aCard.suit ="Spades";
    cardPtr=&aCard;
    printf("%s%s%s\n%s%s%s\n%s%s%s\n",aCard.face," of ",aCard.suit,cardPtr->face," of ",cardPtr->suit
    ,(*cardPtr).face," of ",(*cardPtr).suit);
    return 0;
}
